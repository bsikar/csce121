# include "Passport.h"

using std::string, std::vector;

// TODO: implement constructor using member initializer list

string Passport::getCamperName() {
	// TODO: implement getter

	return "";
}

bool Passport::checkJuniorPassport() {
	// TODO: implement getter

	return false;
}

void Passport::addParkVisited(StatePark* park) {
	INFO(park)

	// TODO: implement function

	return;
}

double Passport::getMilesHiked() {
	// TODO: (optional) implement function

	return 0.0;
}

int Passport::getHikerLevel() {
	// TODO: (optional) implement function

	return 0;
}
