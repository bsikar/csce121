# include "Passport.h"

using std::string, std::vector;

// TODO: implement constructor using member initializer list

string StatePark::getParkName() {
	// TODO: implement getter

	return "";
}

double StatePark::getEntranceFee() {
	// TODO: implement getter

	return 0.0;
}

double StatePark::getTrailMiles() {
	// TODO: implement getter
	
	return 0.0;
}

void StatePark::addCamper(Passport* camper) {
	INFO(camper)

	// TODO: implement function

	return;
}

double StatePark::getRevenue() {
	// TODO: (optional) implement function

	return 0.0;
}
